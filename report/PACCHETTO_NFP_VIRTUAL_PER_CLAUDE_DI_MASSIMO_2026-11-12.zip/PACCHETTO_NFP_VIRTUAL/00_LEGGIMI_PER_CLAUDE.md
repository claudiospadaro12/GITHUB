# Pacchetto per l'analisi indipendente: filtro NFP e Virtual SL/TP (12/11/2026)

Sei Claude e stai aiutando Massimo (fratello di Claudio, progetto ABTG). Claudio ha chiesto a un altro Claude di fare due test nel Strategy Tester di MT5 (broker BCM, dati storici) e ora vuole che tu li riesamini **senza fidarti delle sue conclusioni**. Rispondi in italiano, con i numeri e la fonte (nome del file e riga), e scrivi "NON VERIFICATO" o "NON MISURATO" quando non lo sai. Non dare consigli di lotto, taglia o acquisto.

## Cosa contiene il pacchetto
| File | Cosa e |
|---|---|
| `01_virtual_sltp_passate.csv` | una riga per ogni passata del test Virtual SL/TP (oro + Gold Trade Pro) e del riferimento (D160, virtual spento, ritardo 99) |
| `02_nfp_filtro_passate.csv` | una riga per ogni passata del test con il filtro NFP spento, accanto al riferimento (filtro acceso) |
| `10_CRITERI_VIRTUAL_SLTP.md`, `11_CRITERI_NFP_OFF.md` | criteri e previsioni **scritti prima di vedere i numeri**: le regole di lettura vanno applicate cosi come sono, non cambiate |
| `20_..._di_Claude.md`, `21_..._di_Claude.md` | le conclusioni dell'altro Claude: **leggile SOLO dopo aver fatto la tua analisi dai CSV**, per confrontarle |

## Come sono state fatte le passate
- EA di Wim: Goldbot One, Gold Phantom, Gold Reaper, Gold Trade Pro (XAUUSD), set ufficiali di Wim; Daytrade Pro non ha i due input. Conto da 160.000 EUR, Modello 1, anni 2013 / 2020 / 2025. Goldbot e Gold Trade Pro sono deterministici (1 passata per anno); Phantom e Reaper hanno `Randomization 50`, quindi rumore: 2 ripetizioni per anno (R1, R2).
- **Test 1, Virtual SL/TP**: braccio V99 = `EnableVirtualSLTP=true` con il ritardo dello stop reale a 99 (valore dei set); V0 = true e ritardo 0; C0 = controllo (virtual spento, ritardo 0). Riferimento = passate D160 (virtual spento, ritardo 99).
- **Test 2, filtro NFP**: unico input cambiato `EnableNFP_Filter=false` (nei set e acceso: chiude posizioni e pendenti attorno al rilascio; finestre minuti prima/dopo: Phantom e Reaper 100/60, Goldbot 180/50, Gold Trade Pro 10/240). Riferimento = passate D160 (filtro acceso).
- Colonne: `netto_EUR` (netto del report), `PF`, `DD_equity_pct` (DD equity relativo del report), `peggior_giorno_EUR` (somma dei deal chiusi nel giorno peggiore, calcolata dai deal, con commissioni e swap del tester), `righe_giornale` (righe totali dei giornali del tester per passata: **solo un indizio** del numero di richieste, non il conteggio di FTMO), `posizioni_attraverso_NFP` (posizioni aperte al momento del rilascio dell'NFP, ora server BCM GMT+1; date NFP scelte a mano).

## Avvertenze che devi conoscere
1. **Input ereditati dal tester.** Il tester ricorda l'ultimo valore salvato di ogni input per ogni EA. Le prime passate del Gold Trade Pro (test NFP e Virtual) erano falsate (`FridayStopHour` 19 invece di 25, filtro NFP spento ereditato, ritardo 0 al posto di 99): sono state **scartate e rifatte** con tutti gli input imposti. Nel pacchetto ci sono solo le passate valide; per ognuna e stato verificato che **tutti** gli input del report coincidano con il riferimento tranne quelli del test.
2. Riferimento Reaper L3 2020: la ripetizione R1 e fallita (KO) nel D160, quindi per quell'anno c'e una sola ripetizione (R2). **Per un confronto alla pari l'altro Claude usa R2 sia nel test sia nel riferimento** (Reaper, filtro NFP spento: +6,7%); se si mediano anche le due ripetizioni del test 2020 contro la sola R2 del riferimento si ottiene +7,4%. Dimmi tu quale metodo ritieni corretto e se cambia la conclusione.
3. Il tester NON simula lo spread che si allarga durante le news, ne l'esecuzione reale di FTMO: un risultato "neutro" nel tester non dimostra che sia sicuro.
4. Il significato esatto di `SetVSL_to_hardSL_sec_delay=0` non e verificato (indicazione di seconda mano da Discord): non si sa se con ritardo 0 lo stop reale viene mai messo sul server.
5. Un percorso per anno, 3 anni: non e una statistica; Phantom e Reaper hanno un rumore fra una corsa e l'altra che puo arrivare al 10-15% sul netto di 3 anni.

## Cosa ti chiede Claudio
1. Dai CSV, **ricalcola** per ogni EA (somma dei 3 anni; Phantom e Reaper: media delle ripetizioni): variazione del netto, aumento massimo del DD, peggioramento massimo del peggior giorno, variazione delle operazioni e, per il Virtual SL/TP, la variazione delle righe di giornale. Applica le regole dei file 10 e 11.
2. Dai un tuo verdetto per EA e per test (neutro / migliore / peggiore, e "riduce / non riduce" le richieste), indicando dove i numeri sono dentro il rumore.
3. Poi leggi i file 20 e 21 e dimmi **dove sei d'accordo, dove no e perche**; segnala errori di calcolo, regole applicate male o conclusioni non sostenute dai dati.
4. Rispondi alla domanda pratica: **conviene cambiare qualcosa (spegnere il filtro NFP, accendere il Virtual SL/TP con ritardo 0) o lasciare tutto cosi com'e?** E cosa manca per deciderlo.
Nota: la risposta di FTMO sulla mail dello Swing non e ancora arrivata (stop out e leva dell'oro, prezzo e ripartizione, posizioni opposte tra conti): non e un dato di questi test.
